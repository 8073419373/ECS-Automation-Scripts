const CustomNavbar = props => {
  console.log('Navbar:', props)
  return <h6>Custom Navbar</h6>
}

export default CustomNavbar
