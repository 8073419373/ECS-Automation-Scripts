import { Spinner } from 'reactstrap'

const SpinnerTextAlignment = () => {
  return (
    <div className='text-center'>
      <Spinner />
    </div>
  )
}
export default SpinnerTextAlignment
