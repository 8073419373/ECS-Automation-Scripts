const GlobalVariable = Object.freeze({
    BASE_API_URL:'foodappv2-fe-lb-1910404876.us-east-1.elb.amazonaws.com/'
})

export default GlobalVariable